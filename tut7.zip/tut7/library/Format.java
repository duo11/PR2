package tut7.library;

public enum Format {
    HARDCOVER, PAPERBACK, AUDIOBOOK,
    EBOOK, NEWSPAPER, MAGAZINE, JOURNAL
}
