package tut7.library;

public enum AccountType {
    GENERAL_MEMBER,LIBRARIAN
}
