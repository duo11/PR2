package tut7.library;

public enum AccountStatus {
    ACTIVE, DISABLED, RESTRICTED, BLACKLISTED, DELETED
}
