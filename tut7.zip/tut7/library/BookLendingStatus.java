package tut7.library;

public enum BookLendingStatus {
    AVAILABLE, ON_LOAN, RESERVED, OVERDUE, RENEWED, RECALLED, LOST,
    Damaged, IN_TRANSIT, ON_HOLD, CANCELLED, NOT_AVAILABLE
}
