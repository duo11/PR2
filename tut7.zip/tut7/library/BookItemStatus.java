package tut7.library;

public enum BookItemStatus {
    AVAILABLE, RESERVED, LOANED, LOST

}
