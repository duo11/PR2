package tut6;

public interface Shape2DCalculation {
    double getArea();
    double getPerimeter();
}
