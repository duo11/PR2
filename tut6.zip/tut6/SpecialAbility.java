package tut6;

public interface SpecialAbility {
    void transform();
    void teleport(Point2D position);
}

