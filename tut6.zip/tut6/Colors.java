package tut6;

public enum Colors {
    WHITE,BLACK,RED,PINK,ORANGE,YELLOW,PURPLE,GREEN,BLUE,BROWN
}
