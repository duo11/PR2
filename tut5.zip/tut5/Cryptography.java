package tut5;

public class Cryptography {
    private String plainText;
    private String cipherText;

    public Cryptography () {};
    public Cryptography (String plainText) {
        this.plainText = plainText;
        this.cipherText = plainText;

    }

    public String getPlainText() {
        return plainText;
    }
    public String getCipherText() {
        return cipherText;
    }
    public void setPlainText (String s) throws Exception {
        if(isValidPlainText(s)) {
            this.plainText  = s;
        }
        else{
            throw new Exception("Invalid plain text");
        }
    }
    public void setCipherText (String s) {
        cipherText = s;
    }
    public void encrypt() {}
    public void decrypt() throws Exception {}

    public boolean isValidPlainText(String s) {
        return !s.equals("");
    }


    private boolean isEncrypt () {
        return !(plainText == cipherText);
    }

    @Override
    public String toString () {
        if(isEncrypt()){
            return "[Cryptography[cipherText = " + cipherText + " ]";
        }
        else{
            return "[Cryptography[plainText = "+ plainText +" ]";
        }
    }



}
