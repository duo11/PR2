package tut5;

public class CaesarCipher extends Cryptography {

    public CaesarCipher() {

    }
    public CaesarCipher(String plainText){
        super(plainText);
    }
    @Override
    public void encrypt() {
        StringBuilder sb = new StringBuilder();
        for(int i = 0 ; i < getPlainText().length() ;i++) {
            sb.append((char) (getPlainText().charAt(i) + 3));
        }
        setCipherText(sb.toString());

    }
    @Override

    public void decrypt() throws Exception {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < getCipherText().length(); i++) {
            sb.append((char) (getCipherText().charAt(i) - 3));
        }
        setPlainText(sb.toString());
    }
}
