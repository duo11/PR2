package tut5;

public class Staff extends Person {
    String school;
    double pay;
    public Staff(String name,String address,String school,double pay) throws Exception {
        super(name, address);
        setSchool(school);
        setPay(pay);
    }
    public String getSchool() {
        return school;
    }
    public double getPay() {
        return pay;
    }
    public void setSchool(String s) throws Exception {
        if(isValidSchool(s)){
            this.school = school;
        }
        else{
            throw new Exception("Invalid school");
        }
    }
    public void setPay(double p) throws Exception {
        if(isValidPay(p)) {
            this.pay = p;
        }
        else{
            throw new Exception("Invalid Pay");
        }
    }
    public boolean isValidSchool (String s) {
        return s.matches("[a-zA-Z]+");
    }
    public boolean isValidPay (double pay) {
        return pay > 0;
    }
    @Override
    public String toString() {
        return "Staff[Person[name="+ this.getName() +",address="+this.getAddress()+"],school="+this.school+",pay="+this.pay+"]";
    }

}
