package tut5;

public class Student extends Person {
    private String program;
    private int year;
    private double fee;

    public Student() {};
    public Student(String name,String address,String program,int year,double fee) throws Exception {
        super(name, address);
        setProgram(program);
        setYear(year);
        setFee(fee);
    }
    public String getProgram() {
        return program;
    }
    public void setProgram(String s) throws Exception {
        if(isValidProgram(s)){
            this.program = program;
        }
        else{
            throw new Exception("Wrong program format");
        }
    }
    public int getYear(){
        return year;
    }
    public void setYear(int year) throws Exception {
        if(isValidYear(year)){
            this.year = year;
        }
        else{
            throw new Exception("Invalid year");
        }
    }
    public double getFee() {
        return fee;
    }
    public void setFee(double f) throws Exception{
        if(isValidFee(f)){
            this.fee = f;
        }
        else{
            throw new Exception("Invalid fee");
        }
    }
    private boolean isValidYear (int year) {
        return year > 0;
    }
    private boolean isValidFee(double fee) {
        return fee > 0;
    }
    private boolean isValidProgram(String s) {
        return !s.matches(".*\\W+.*");//return false if the string have at least one special character
    }
    @Override
    public String toString() {
        return "Student[Person[name=" + this.getName() + ",address= "+this.getAddress()+"],program="+this.program+",year="+this.year+",fee="+this.fee+"]";
    }

}
