package tut5;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Shape {
    private String color;
    private boolean filled;

    public Shape() {};
    public Shape(String color,boolean filled) throws Exception {
        setColor(color);
        this.filled = filled;
    }
    public String getColor() {
        return color;
    }
    public void setColor (String color) throws Exception {
        if(isValidColor(color)){
            this.color = color;
        }
        else{
            throw new Exception("Invalid color");
        }
    }
    public boolean isFilled() {
        return filled;
    }
    public void setFilled (boolean filled) {
        this.filled = filled;
    }

    private boolean isValidColor(String color) {
        Pattern pattern = Pattern.compile("#([0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})");
        Matcher matcher = pattern.matcher(color);
        return matcher.matches();

    }
    public String toString() {
        return "Shape[color="+color+",filled"+filled+"]";
    }

}
