package tut5;

public class test {
    public static void main(String[] args) throws Exception {
        Student s1 = new Student("duong","duong@gmail.com","it123",2,15000);
        Staff s23 = new Staff("asd","Asd","asd12",12);


    }
}
