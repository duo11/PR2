package tut5;

public class Square extends Rectangle {
    public Square () {};
    public Square (double side) {
        super(side,side);
    }
    public Square (double side,String color,boolean filled) throws Exception {
        super(side,side,color,filled);
    }
    public double getSide() {
        return getLength();
    }
    public void setSide(double side) {
        setWidth(side);
        setLength(side);
    }
    @Override
    public void setWidth(double side) {
        setSide(side);
    }
    @Override
    public void setLength(double side) {
        setSide(side);
    }
    @Override
    public String toString() {
        return "Square[Rectangle[Shape[color="+getColor()+",filled="+isFilled()+",width="+getWidth()+",length="+getLength()+"]";
    }

}
