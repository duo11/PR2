package tut5;

public class AES extends Cryptography {

}
