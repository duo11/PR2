package tut5;
import java.lang.Math;
public class Rectangle extends Shape {
    private double width = 1.0;
    private double length = 1.0;

    public Rectangle() {};
    public Rectangle(double width,double length) {
        this.width = width;
        this.length = length;
    }
    public Rectangle(double width,double length,String color,boolean filled) throws Exception {
        super(color,filled);
        this.width = width;
        this.length = length;
    }
    public double getWidth () {
        return width;
    }
    public double getLength() {
        return length;
    }
    public void setWidth(double width) throws Exception {
        if(isValidSide(width)){
            this.width = width;
        }
        else{
            throw new Exception("Invalid width");
        }
    }
    public void setLength (double length) throws Exception {
        if(isValidSide(length)){
            this.length = length;
        }
        else{
            throw new Exception("Invalid length");
        }
    }
    public double getArea() {
        return width * length;
    }
    public double getPerimeter() {
        return 2*(width+length);
    }

    private boolean isValidSide(double d) {
        return d > 0 ;
    }
    public String toString() {
        return "[Rectangle[Shape[color="+getColor()+",filled="+isFilled()+",width="+width+",length="+length+"]";
    }
}
